
function b = Convert(a)
    b = double(categorical(a));
    for c = 1 : length(a) %number of rows
        if a(c) == "no"
            b(c) = 0 ;
        else
            b(c) = 1; %yes
        end
    end
end