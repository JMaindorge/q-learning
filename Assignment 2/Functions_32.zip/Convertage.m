function b = Convert(age)
    age = double(a);
    b = double(age);
    for c = 1 : length(age) %number of rows
        if age(c) < 18
            b(c) = "True" %"Under 18";
        else
            b(c) = "False";
        end
    end
end

function b = Convert(a)
    b = double(categorical(a));
    for c = 1 : length(a) %number of rows
        if a(c) == 'GP'
            b(c) = 0 %"Under 18";
        else
            b(c) = 1;
        end
    end
end