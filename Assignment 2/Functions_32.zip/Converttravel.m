
function b = Convert(a)
    b = double(a);
    for c = 1 : length(a) %number of rows
        if a(c) < 3
            b(c) = 0 ; %Less than 30 minutes
        else
            b(c) = 1; %30 minutes or more
        end
    end
end