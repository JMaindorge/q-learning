function b = Convert(a)
    b = double(categorical(a));
    for c = 1 : length(a) %number of rows
        if a(c) == "M"
            b(c) = 0 ;
        else
            b(c) = 1; %F
        end
    end
end