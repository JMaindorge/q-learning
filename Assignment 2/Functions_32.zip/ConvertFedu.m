
function b = Convert(a)
    b = double(a);
    for c = 1 : length(a) %number of rows
        if a(c) < 2
            b(c) = 0 ; %Other guardian
        else
            b(c) = 1; %secondary or higher
        end
    end
end