
function b = Convert(a)
    b = double(categorical(a));
    for c = 1 : length(a) %number of rows
        if a(c) == "home"
            b(c) = 1 ; %Reason near to home
        else
            b(c) = 0; 
        end
    end
end