
function b = Convert(a)
    b = double(categorical(a));
    for c = 1 : length(a) %number of rows
        if a(c) == "GP"
            b(c) = 0 ;
        else
            b(c) = 1; %MS
        end
    end
end

%new = ConvertGP(dataframe.school) &is an array
%new = array2table(new) %convert to dataframe
%dataframe = [dataframe new];

%newschool newsex