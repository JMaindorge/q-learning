
function b = Convert(a)
    b = double(categorical(a));
    for c = 1 : length(a) %number of rows
        if a(c) == "health"
            b(c) = 1 ; %Job - care related
        else
            b(c) = 0; 
        end
    end
end