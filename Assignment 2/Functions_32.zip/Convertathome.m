
function b = Convert(a)
    b = double(categorical(a));
    for c = 1 : length(a) %number of rows
        if a(c) == "at_home"
            b(c) = 1 ; %Job - at home
        else
            b(c) = 0; 
        end
    end
end