
function b = Convert(a)
    b = double(categorical(a));
    for c = 1 : length(a) %number of rows
        if a(c) == "services"
            b(c) = 1 ; %Job - civil
        else
            b(c) = 0; 
        end
    end
end