
function b = Convert(a)
    b = double(categorical(a));
    for c = 1 : length(a) %number of rows
        if a(c) == "mother"
            b(c) = 1 ; %mother
        else
            b(c) = 0; 
        end
    end
end