
function b = Convert(a)
    b = double(categorical(a));
    for c = 1 : length(a) %number of rows
        if a(c) == "A"
            b(c) = 0 ;
        else
            b(c) = 1; %T
        end
    end
end