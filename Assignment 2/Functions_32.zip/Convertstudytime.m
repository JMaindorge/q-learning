
function b = Convert(a)
    b = double(a);
    for c = 1 : length(a) %number of rows
        if a(c) < 3
            b(c) = 0 ; %Less than 5 hours
        else
            b(c) = 1; %5 hours or more
        end
    end
end