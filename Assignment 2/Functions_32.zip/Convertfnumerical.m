
function b = Convert(a)
    b = double(a);
    for c = 1 : length(a) %number of rows
        if a(c) < 2 %%numeric: from 1 - very bad to 5 - excellent
            b(c) = 0 ; %Less than 2 
        else
            b(c) = 1; %3 failures or more
        end
    end
end