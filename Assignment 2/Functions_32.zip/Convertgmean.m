
function b = Convert(a)
    b = double(a);
    for c = 1 : length(a) %number of rows
        if a(c) > mean(b)
            b(c) = 1 ; %other
        else
            b(c) = 0; %Some relative (father or mother)
        end
    end
end