
function b = Convert(a)
    b = double(categorical(a));
    for c = 1 : length(a) %number of rows
        if a(c) == "other"
            b(c) = 1 ; %other
        else
            b(c) = 0; %Some relative (father or mother)
        end
    end
end